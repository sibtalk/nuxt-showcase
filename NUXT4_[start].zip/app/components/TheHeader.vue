<template>
  <header class="bg-slate-800 shadow-md">
    <nav class="container mx-auto px-4 py-4 flex items-center gap-x-4">
      <!-- Мы используем наш универсальный "атом" -->
      <AppButton to="/">Главная</AppButton>
      <AppButton to="/services">Услуги</AppButton>
    </nav>
  </header>
</template>
