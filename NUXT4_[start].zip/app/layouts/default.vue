<template>
  <div>
    <TheHeader />
    <main>
      <slot />
    </main>
  </div>
</template>
